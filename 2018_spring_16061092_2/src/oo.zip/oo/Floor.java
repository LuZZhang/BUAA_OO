package oo; 

public class Floor {  

} 
 