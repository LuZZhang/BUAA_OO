package com.oo;

import java.util.ArrayList;

public class ReqQue {
	private static ArrayList<Req> queue = new ArrayList<Req>();
	private static ArrayList<Integer> valid = new ArrayList<Integer>();
	
	public void addReq(Req Rq) {
		queue.add(Rq);
		valid.add(1);  
	}
	public void subReq(){
		queue.remove(0);
		valid.remove(0);
	}
	public int RQnum() {
		return queue.size();
	}
	public Req nowRq(int i) {
		return queue.get(i);
	}
	public void setvalid(int i) {
		valid.set(i, 0);
	}
	public int nowvalid() {
		return valid.get(0);
	}

}
